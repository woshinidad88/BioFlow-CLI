STRINGS = {
    # === 主菜单 ===
    "app_title": "BioFlow-CLI  生物信息学工作流工具",
    "menu_prompt": "请选择操作：",
    "menu_env": "[环境] 安装生物工具",
    "menu_seq": "[序列] 格式化处理",
    "menu_settings": "[设置] 切换语言",
    "menu_exit": "[退出] 退出程序",

    # === 语言选择 ===
    "lang_prompt": "请选择语言：",
    "lang_saved": "语言偏好已保存。",

    # === 环境管理 ===
    "env_title": "环境管理器",
    "env_select_tool": "请选择要安装的工具：",
    "env_installing": "正在安装 {tool}...",
    "env_install_ok": "{tool} 安装成功。",
    "env_install_fail": "{tool} 安装失败：{err}",
    "env_back": "返回主菜单",
    "env_already": "{tool} 已安装。",
    "env_not_found": "未找到 {tool}，准备安装。",
    "env_checking": "正在检查 {tool} 状态...",

    # === 序列任务 ===
    "seq_title": "序列格式化",
    "seq_input_prompt": "请输入 FASTA/FASTQ 文件路径：",
    "seq_output_prompt": "请输入输出文件路径：",
    "seq_processing": "正在处理序列...",
    "seq_done": "完成！已格式化 {count} 条序列，保存至 {path}。",
    "seq_file_not_found": "文件未找到：{path}",
    "seq_invalid_format": "无效的序列格式，仅支持 FASTA/FASTQ。",
    "seq_back": "返回主菜单",
    "seq_wrap_prompt": "每行字符宽度（默认 80）：",
    "seq_fastq_stats": "FASTQ 质量摘要：平均 Q={avg_q}，Q20={q20}，Q30={q30}，碱基数={bases}",

    # === 通用 ===
    "confirm_exit": "确定要退出吗？",
    "yes": "是",
    "no": "否",
    "goodbye": "再见！",
    "error_unexpected": "发生意外错误：{err}",
    "press_enter": "按 Enter 键继续...",
    "env_conda_missing": "未检测到 Conda，请先安装 Conda（https://docs.conda.io/）。",
    "seq_large_file_warn": "警告：文件大小为 {size} MB，可能占用大量内存。",

    # === 质控流程 ===
    "menu_qc": "[质控] QC Pipeline",
    "qc_title": "质控流程",
    "qc_input_prompt": "请输入 FASTQ 文件路径：",
    "qc_output_prompt": "请输入输出目录：",
    "qc_adapter_prompt": "Adapter 文件路径（留空跳过）：",
    "qc_minlen_prompt": "最短读长（默认 36）：",
    "qc_pipeline_start": "开始质控流程：{file}",
    "qc_pipeline_done": "质控流程完成！结果保存至：{output}",
    "qc_step_label": "[步骤 {step}] {name}",
    "qc_step_failed": "步骤失败（{step}）：{err}",
    "qc_running_fastqc": "正在运行 FastQC：{file}...",
    "qc_running_trimmomatic": "正在运行 Trimmomatic：{file}...",

    # === 工具预检 ===
    "preflight_missing_cli": "错误：未找到 {tool}。安装命令：{cmd}",
    "preflight_missing_tui": "未找到 {tool}。安装命令：{cmd}",
    "preflight_unknown_tool": "错误：未知工具 '{tool}'",
    "preflight_hint_env_manager": "提示：使用 [环境] 菜单安装缺失工具，或手动安装。",

    # === 批量处理 ===
    "batch_processing": "批量处理文件中...",
    "batch_no_files": "未找到匹配的文件。",
    "batch_success_title": "✓ 处理成功",
    "batch_failed_title": "✗ 处理失败",
    "batch_skipped_title": "⊙ 已跳过",
    "batch_col_file": "文件名",
    "batch_col_sequences": "序列数",
    "batch_col_output": "输出文件",
    "batch_col_time": "耗时",
    "batch_col_error": "错误信息",
    "batch_col_reason": "原因",
    "batch_summary": "总计：{total} 个文件 | 成功：{success} | 失败：{failed} | 跳过：{skipped}",
}
